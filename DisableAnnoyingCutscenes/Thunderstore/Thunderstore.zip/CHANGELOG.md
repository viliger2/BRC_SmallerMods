<details>
<summary>1.0.0 </summary>

* Initial release
</details>