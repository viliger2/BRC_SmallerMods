# ActualPrinterIcon
Gives all printers (a.k.a duplicators) their own unique icon on pinging and scanning. Can be run client-side.